﻿/// <reference path="jquery-1.8.1-vsdoc.js" />

$(document).ready(function() {
    var aspTrace = $('#__asptrace');
    aspTrace.css({
        'background-color': '#fff',
        'border': '1px solid #000',
        'position': 'fixed',
        'top': '50px',
        'left': '50px',
        'bottom': '50px',
        'right': '50px',
        'overflow-y': 'scroll',
        'overflow-x': 'hidden'
    });
    aspTrace.hide();
    $('body').append('<div style="position: fixed; bottom: 5px; right: 10px"><a href="javascript:none" id="pi">&pi;</a></div>');
    $('a#pi').on('click', function () {
        aspTrace.fadeToggle('fast', null);
    });
});

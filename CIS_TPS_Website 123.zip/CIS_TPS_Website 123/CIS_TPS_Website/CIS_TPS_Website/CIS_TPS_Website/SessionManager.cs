﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CIS_TPS_Website
{
    static class SessionManager
    {
        public static String UserID
        {
            get
            {
                return HttpContext.Current.Session["UserID"].ToString();
            }
            set
            {
                HttpContext.Current.Session["UserID"] = value;
            }
        }

        // add other properties as needed
    }
}
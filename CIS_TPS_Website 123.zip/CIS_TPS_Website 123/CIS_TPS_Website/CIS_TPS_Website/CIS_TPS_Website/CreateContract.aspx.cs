﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.OleDb;
using System.Data;

namespace CIS_TPS_Website
{
    public partial class CreateContract : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            OleDbConnection connect = new OleDbConnection();
            connect.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\\TEMP\\CIS_TPS_Website 123\\CIS_TPS_Website\\CIS_TPS_Website\\TPS.accdb";
            connect.Open();

            string strSQL = "INSERT into requisition (requistion_Ed, requistion_Field, requistion_Salary, requistion_City, requistion_State) values (@red, @rfd, @rs, @rc, @rst)";

            OleDbCommand command = new OleDbCommand(strSQL, connect);
            command.Connection = connect;
            command.CommandType = CommandType.Text;
            command.CommandText = strSQL;
            command.Parameters.AddWithValue("@red", txtReqEd.Text);
            command.Parameters.AddWithValue("@rfd", txtReqField.Text);
            command.Parameters.AddWithValue("@rs", txtReqSalary.Text);
            command.Parameters.AddWithValue("@rc", txtReqCity.Text);
            command.Parameters.AddWithValue("@rst", txtReqState.Text);
            command.ExecuteNonQuery();
            connect.Close();
            Response.Redirect("ClientHome.aspx");
        }
    }
}